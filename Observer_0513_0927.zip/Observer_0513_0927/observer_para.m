J = 2.09e-5;
B = 0.00002;
Kt = 0.042;
Kb = 0.042;
R = 8.4;
L = 1.16;

A = [0 1 0 ;
     0 -B/J Kt/J;
     0 -Kb/L -R/L];
Bm = [0 0 1/L];
C = [1 0 0];
D = 0;

%%%%%% 관측기 설계 %%%%%%%
% 가관측성 확인
observ_matrix = obsv(A,C)
rank(observ_matrix) % 3=3

% 우리가 원하는 eign value 로 움직일 수 있는 L을 구해야 함

eigen = [-50 -50 -50]; % 우리가 원하는 pole placement
Lgain = acker(A',C',eigen) % 우리가 원하는 pole placement에 의한 각각의 L gain을 구한 거래
L1 = Lgain(1) % theta
L2 = Lgain(2) % omega
L3 = Lgain(3) % current

% 이 L1, L2, L3을 가지고 관측기를 설계함


%%%%%% state-feedback controller 설계 %%%%%%%%
% 가제어성 확인
contrl_matrix = ctrb(A,Bm')
rank(contrl_matrix) % 3=3
pinv(Bm') % B+

Kgain = acker(A,Bm',eigen)
K1 = Kgain(1)
K2 = Kgain(2)
K3 = Kgain(3)

